using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public static class MapController
{
    [SerializeField]public static int levelsUnlocked;
    [SerializeField]public static int levelsCleared;

    public static void SetLevels(UserData data)
    {
        levelsCleared = data.levelsCleared;
        levelsUnlocked = data.levelsUnlocked;
        RefreshLevels();
    }

    public static void RefreshLevels()
    {
        GameObject[] levelButtons = GameObject.FindGameObjectsWithTag("LevelButton");
        foreach (var button in levelButtons)
        {
            button.GetComponent<Button>().interactable = button.GetComponent<Level>().levelNumber <= levelsUnlocked;
        }
    }

    public static void ClearProgress()
    {
        levelsCleared = 0;
        levelsUnlocked = 0;
        SaveSystem.Save(new UserData(0,0));
        RefreshLevels();
        Debug.Log("Clear done");
    }
}
