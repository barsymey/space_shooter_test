using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


public static class SaveSystem
{
    private static string path = Application.persistentDataPath + "/save.sav";
    public static void Save(UserData data)
    { 
        BinaryFormatter formatter = new BinaryFormatter();
        FileStream stream = new FileStream(path,FileMode.Create);
        
        formatter.Serialize(stream, data);
        
        stream.Close();
    }

    public static UserData Load()
    {
        if(File.Exists(path))
        {
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream stream = new FileStream(path, FileMode.Open);
            
            UserData data = formatter.Deserialize(stream) as UserData;
            stream.Close();
            return data;
        }
        return new UserData(0,0);
    }
}
