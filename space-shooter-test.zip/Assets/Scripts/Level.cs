using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level : MonoBehaviour
{
    [SerializeField] public int levelNumber;
    [SerializeField] public int asteroidRate;
    [SerializeField] public int goal;
    [SerializeField] public GameObject[] asteroidTypes;
}
