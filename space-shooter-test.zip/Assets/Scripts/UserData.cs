using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class UserData
{
    public int levelsUnlocked;
    public int levelsCleared;

    public UserData(int unlocked, int cleared)
    {
        levelsCleared = cleared;
        levelsUnlocked = unlocked;
    }
}
