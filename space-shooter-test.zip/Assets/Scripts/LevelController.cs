using System;
using System.Collections;
using System.Collections.Generic;
using UniRx;
using UnityEngine;
using Random = UnityEngine.Random;

public class LevelController : MonoBehaviour
{
    [SerializeField] private GameObject playerSpawn;
    [SerializeField] private GameObject player;
    [SerializeField] private GameObject asteroidSpawn;
    private static int currentLevel;
    private static float asteroidRate;
    private float nextAsteroid;
    public static GameObject[] asteroidTypes;


    private void Start()
    {
        Counter.goal
            .Where(a => a <= 0)
            .Subscribe(a => LevelCleared());
    }

    private void FixedUpdate()
    {
        SpawnAsteroid();
    }

    public void InitLevel(Level lvl)
    {
        currentLevel = lvl.levelNumber;
        asteroidRate = lvl.asteroidRate;
        asteroidTypes = lvl.asteroidTypes;
        Counter.goal.Value = lvl.goal;
        StartLevel();

    }

    private void SpawnAsteroid()
    {
        if (nextAsteroid < Time.timeSinceLevelLoad)
        {
            Instantiate(asteroidTypes[Random.Range(0, asteroidTypes.Length)], new Vector3(Random.Range(-6,6),asteroidSpawn.transform.position.y,asteroidSpawn.transform.position.z),asteroidSpawn.transform.rotation);
            nextAsteroid = Time.timeSinceLevelLoad + 2/asteroidRate;
        }

    }
    public void StartLevel()
    {
        Destroy(GameObject.FindWithTag("Player"));
        Instantiate(player, playerSpawn.transform.position, playerSpawn.transform.rotation);
        UI.HideScreens();
        UI.Unpause();
    }
    
    public static void GameOver()
    {
        UI.ShowGameOverScreen();
    }

    public static void LevelCleared()
    {
        if (currentLevel >= MapController.levelsUnlocked)
        {
            Debug.Log(MapController.levelsUnlocked);
            MapController.levelsCleared = currentLevel;
            MapController.levelsUnlocked = currentLevel+1;
            Debug.Log(MapController.levelsUnlocked);
        }
        UI.ShowLevelClearedScreen();
        SaveSystem.Save(new UserData(MapController.levelsUnlocked, MapController.levelsCleared));
    }
}
