using System.Collections;
using System.Collections.Generic;
using UniRx;
using UniRx.Triggers;
using UnityEditor.Experimental;
using UnityEngine;
using UnityEngine.UI;

public class UI : MonoBehaviour
{

    [SerializeField] private Text lives;
    [SerializeField] private Text goal;
    private static GameObject MapScreen;
    private static GameObject GameOverScreen;
    private static GameObject LevelClearedScreen;
    void Start()
    {
        MapScreen = GameObject.Find("MapScreen");
        GameOverScreen = GameObject.Find("GameOverScreen");
        LevelClearedScreen = GameObject.Find("LevelClearedScreen");
        
        Counter.playerHealth
            .Select(health => health.ToString())
            .Subscribe(text => lives.text = "Lives Left: " + text);
        Counter.goal
            .Select(health => health.ToString())
            .Subscribe(text => goal.text = "Asteroids to destroy: " + text);
        Debug.Log(Application.persistentDataPath);
        MapController.SetLevels(SaveSystem.Load());
        ShowMapScreen();
    }

    public static void ShowGameOverScreen()
    {
        HideScreens();
        GameOverScreen.SetActive(true);
        Pause();
    }
    
    public static void ShowLevelClearedScreen()
    {
        HideScreens();
        LevelClearedScreen.SetActive(true);
        Pause();
    }
    
    public static void ShowMapScreen()
    {
        HideScreens();
        MapScreen.SetActive(true);
        Pause();
        MapController.RefreshLevels();

    }
    
    public static void HideScreens() 
    {
        MapScreen.SetActive(false);
        GameOverScreen.SetActive(false);
        LevelClearedScreen.SetActive(false);
    }

    public static void Pause()
    {
        Time.timeScale = 0;
    }
    
    public static void Unpause()
    {
        Time.timeScale = 1;
    }

    public void ClearProgress()
    {
        MapController.ClearProgress();

    }
}
