using System.Collections;
using System.Collections.Generic;
using UniRx;
using UnityEngine;

public static class Counter
{
    public static ReactiveProperty<int> goal = new ReactiveProperty<int>(1);
    public static ReactiveProperty<int> playerHealth = new ReactiveProperty<int>(1);
}
