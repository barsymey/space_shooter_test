using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

public class Rotation : MonoBehaviour
{
    private Vector3 rotation;

    private void Start()
    {
        rotation = new Vector3(Random.Range(1,180),Random.Range(1,180),Random.Range(1,180));
    }

    void FixedUpdate()
    {
        transform.Rotate(rotation*Time.deltaTime);
    }
}
