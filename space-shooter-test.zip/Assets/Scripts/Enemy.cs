using System;
using System.Collections;
using System.Collections.Generic;
using UniRx;
using UniRx.Triggers;
using UnityEngine;
using Random = UnityEngine.Random;

public class Enemy : Entity
{
    [SerializeField] private int initHP;
    [SerializeField] private int maxSpeed;
    private Vector3 movementVector;

    private void Start()
    {
        movementVector = new Vector3(Random.Range(-maxSpeed,maxSpeed)/5, -Random.Range(1, maxSpeed),0.0f);
        hitPoints = initHP;
    }

    private void FixedUpdate()
    {
        transform.Translate(movementVector*Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.CompareTag("Player"))
        {
            other.gameObject.GetComponent<Player>().GetHit(1);
            Destroy(gameObject);
        }

        if (other.CompareTag("Projectile"))
        {
            GetHit(1);
            Destroy(other.gameObject);
        }
    }

    public override int GetHit(int amount)
    {
        if(base.GetHit(amount) <=0)
        {
            Counter.goal.Value--;
            Destroy(gameObject);
        }
        return 0;
    }
}
