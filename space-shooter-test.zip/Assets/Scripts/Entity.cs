using System.Collections;
using System.Collections.Generic;
using UniRx;
using UnityEngine;

public class Entity : MonoBehaviour
{
    [SerializeField] public int hitPoints = 0;


    public virtual int GetHit(int amount)
    {
        hitPoints -= amount;
        if (hitPoints <= 0) hitPoints = 0;
        return hitPoints;
    }

    public void SetHit(int amount)
    {
        hitPoints = amount;
    }
}
