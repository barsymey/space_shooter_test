using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    [SerializeField] private float speed;
    [SerializeField] private float lifeTime = 1;
    private float destructionTime;

    private void Start()
    {
        destructionTime = Time.timeSinceLevelLoad + lifeTime;
    }

    void Update()
    {
        transform.Translate(new Vector3(0.0f, 
            speed*Time.deltaTime, 0.0f));
        if(destructionTime < Time.timeSinceLevelLoad) Destroy(gameObject);
    }
}
