using System;
using System.Collections;
using System.Collections.Generic;
using UniRx;
using UniRx.Triggers;
using UnityEngine;
using UnityEngine.UI;

public class Player : Entity
{
    [SerializeField] private int initHP;
    [SerializeField] private float movementSpeed = 10;
    [SerializeField] private float weaponCooldown = 1;
    [SerializeField] private GameObject projectile;
    private DateTimeOffset _lastFired;

    private void Start()
    {
        SetHit(initHP);
        this.UpdateAsObservable()
            .Where(_ => Input.GetMouseButton(0))
            .Timestamp()
            .Where(x => x.Timestamp > _lastFired.AddSeconds(weaponCooldown))
            .Subscribe(x =>
            {
                Fire();
                _lastFired = x.Timestamp;
            });

        this.UpdateAsObservable()
            .Where(x => Input.GetAxis("Horizontal") != 0)
            .Subscribe(x =>
            {
                Move(Input.GetAxis("Horizontal")*Time.deltaTime*movementSpeed);
            });
        Counter.playerHealth.Value = hitPoints;
    }

    private void Fire()
    {
        Instantiate(projectile, transform.position, transform.rotation);
    }

    private void Move(float move)
    {
        transform.Translate(new Vector3(move, 0.0f, 0.0f));
    }
    
    public override int GetHit(int amount)
    {
        if(base.GetHit(amount) <= 0)
        {
            Destroy(gameObject);
            LevelController.GameOver();
        }
        Counter.playerHealth.Value = hitPoints;
        return 0;
    }
}
